Hey! Thanks for downloading my game
To play it you just need to extract both Gunslash.exe and the data folder to the same folder, double click on the .exe and you're good to go!

By default, you move with WASD, jump with the spacebar, shoot with the left click and use your melee attack with the right click. 

This project is still in development and some features aren't available. For example: if you die, you have to restart the game by hand. And if you want to close the game erm... use alt-tab. I'm working on it. Sorry, first project yadda yadda.