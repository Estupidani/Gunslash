Hey! Thanks for downloading my game
To play it you just need to extract both Gunslash.exe and the data folder to the same folder, double click on the .exe and you're good to go!

By default, you move with WASD, jump with the spacebar, shoot with the left click and use your melee attack with the right click. 

This project is still in development and you may encounter some bugs, weird behaviours and absolutely terrible art. I'm working on it but it'll take time, specially that last part. Sorry, first project yadda yadda.